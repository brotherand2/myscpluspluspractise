# include<stdio.h>
# include<string.h>
typedef struct node
{
	int num;
	char name[15];
	struct node *next;
}LNode,*LinkList;
void createLinkList(LinkList *head)
{
	LinkList p,r;
	int num;
	char name[15];
	printf("please input the num:");
	scanf("%d",&num);
	//getchar();
	printf("please input the name:");
	scanf("%s",name);
	p=(LinkList)malloc(sizeof(LNode));
	p->num=num;
	p->next=NULL;
	strcpy(p->name,name);
	while(num)
	{
		if(*head==NULL)
			*head=p;
		else
			r->next=p;
		r=p;
		printf("please input the num:");
		scanf("%d",&num);
		//getchar();
		printf("please input the name:");
		scanf("%s",name);
		p=(LinkList)malloc(sizeof(LNode));
		p->num=num;
		p->next=NULL;
		strcpy(p->name,name);

	}
}
void traverseLinkList(LinkList head)
{
	printf("\nthe result is:\n");
	while(head)
	{
		printf("num:%d   name:%s\n",head->num,head->name);
		head=head->next;
	}
}
void insertList(LinkList *head)
{
	LinkList p,p1,p2;
	int num;
	char name[15];
	p1=p2=*head;
	while(p1)
	{
		p2=p1;
		p1=p1->next;
	}
	printf("please input the num you want to insert:");
	scanf("%d",&num);
	printf("please input the name :");
	scanf("%s",name);
	p=(LinkList)malloc(sizeof(LNode));
	p->num=num;
	strcpy(p->name,name);
	p->next=NULL;
	if(!p2)
      *head=p;
	else
	  p2->next=p;
}
int listLength(LinkList head)
{
	int count=0;
	while(head)
	{
		count++;
		head=head->next;
	}
	return count;
}
void reverse(LinkList *head)
{
	LinkList p=*head,point,next;
	if(!p)
		return;
    point=p->next;
	if(!point)
		return;//ֻ��1���ڵ㲻�ô���
	next=point->next;
	p->next=NULL;
	point->next=p;
	p=point;
	point=next;
	if(!point)
	{
		*head=p;
		return;//ֻ��2���ڵ��Ѵ���
	}
	while(point->next)
	{
		next=point->next;
		point->next=p;
		p=point;
		point=next;
	}
	point->next=p;
	*head=point;
}
void insert(LinkList *head,int local)
{
	char name[15];
    LinkList p,q=*head;
	int num,count;

	if(local<1||local>listLength(*head)+1)
	{
		printf("insert error!\n");
		return ;
	}
	printf("please input the num:");
	scanf("%d",&num);
	//getchar();
	printf("please input the name:");
	scanf("%s",name);
	p=(LinkList)malloc(sizeof(LNode));
	p->num=num;
	p->next=NULL;
	strcpy(p->name,name);
	if(local==1)
	{
		p->next=*head;
        *head=p;
	}
	else
	{
		for(count=1;count<local-1;count++)
            q=q->next;
		p->next=q->next;
		q->next=p;
	}

}
void delet(LinkList *head,int local)
{
	LinkList r,p;
	int i;
	if(*head==NULL)
	{
		printf("there is no data to delete\n");
		return;
	}
	r=*head;
	p=r->next;

	if(local<1||local>listLength(*head))
	{
		printf("delete error!\n");
		return;
	}
	if(local==1)
	{
		free(r);
		*head=p;
	}
	else
	{
		for(i=2;i<local;i++)
		{
			r=p;
			p=p->next;
		}
		r->next=p->next;
		free(p);
	}

}
void clear(LinkList head)
{
	LinkList p,r;
	p=r=head;
	while(p)
	{
		r=p->next;
		free(p);
		p=r;
	}

}
void sort(LinkList head)
{
    int len=listLength(head),i,j,num;
	char name[15];
	LinkList p=head;
	for(i=0;i<len-1;i++)
	{
		for(j=0;j<len-1-i;j++)
		{
			if(p->num>p->next->num)
			{
				num=p->num;
				p->num=p->next->num;
				p->next->num=num;
				strcpy(name,p->name);
				strcpy(p->name,p->next->name);
				strcpy(p->next->name,name);
			}
			p=p->next;
		}
		p=head;
	}
}
void search(LinkList head,int n)
{
	int i;
	if(!head)
	{
		printf("there is no data in list\n");
		return;
	}
	for(i=0;i<n-1;i++)
		head=head->next;
		printf("num:%d   name:%s\n",head->num,head->name);
	
}
void menu()
{
	printf("========================================================================\n");
	printf("===============0�����ң�1�����룻2��ָ��λ�ò��룻3��ָ��λ��ɾ����=====\n");
	printf("==========================4������5��������ת��6���˳�=================\n");
	
	printf("========================================================================\n");
}
void main()
{
	LinkList head=NULL;
	int n,num,flag=1;
	createLinkList(&head);
	traverseLinkList(head);
	while(flag)
	{
		menu();
		printf("input you choice:");
		scanf("%d",&n);
		switch(n)
		{
		case 0:
            printf("input which you want to input:");
			scanf("%d",&num);
			search(head,num);
			break;
		case 1:
			insertList(&head);
			traverseLinkList(head);
			break;
		case 2:
            printf("input which you want to input:");
			scanf("%d",&num);
			insert(&head,num);
			traverseLinkList(head);
			break;
		case 3:
            printf("input which you want to delete:");
			scanf("%d",&num);
			delet(&head,num);
			traverseLinkList(head);
            break;
		case 4:
			sort(head);
			traverseLinkList(head);
            break;
		case 6:
			flag=0;
			break;
        case 5:
			reverse(&head);
			traverseLinkList(head);
			break;
		default:
			printf("input error!\n");
			break;

		}

	}
	clear(head);
}