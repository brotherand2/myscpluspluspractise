//# include<stdio.h>
//# include"string.c"
void main()
{
	char s1[16],s2[6];
	printf("input s1:");
	gets(s1);
	printf("s1=%s,len=%d\n",s1,strlen(s1));
    strcpy(s2,s1);
	printf("s2=%s\n",s2);
	getchar();
}