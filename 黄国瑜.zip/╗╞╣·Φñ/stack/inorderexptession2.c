# include<stdio.h>
# include<stdlib.h>
typedef struct Node
{
	float data;
    struct Node *next;
}stack,*link;
typedef struct 
{
	char *top;
	char *base;
	int stackSize;

}SqStack,*Link;

link operand=NULL;//������
Link operators=NULL;//�����

void initStack(SqStack *s)
{
	s->top=s->base=(char*)malloc(sizeof(char)*10);
	s->stackSize=10;
}
void Push(SqStack *s,char e)
{
   if(s->top-s->base==10)
   {
	   s->base=(char*)realloc(s->base,(s->stackSize+10)*sizeof(char));
	   s->top=s->base+10;
	   s->stackSize+=10;
   }
   *(s->top)=e;
   s->top++;

}
void Pop(SqStack *s,char *e)
{
	if(s->top==s->base)
		printf("the stack is null");
	else
	{
		s->top--;
		*e=*(s->top);
	}
}

float two_result(float a,float b,char e)
{
	switch(e)
	{
	case '+':return a+b;
	case '-':return a-b;
	case 'x':return a*b;
	case '/':return a/b;
	}
}
int isEmpty(Link s)
{
	return s->base==s->top;
}

link push(link head,float c)
{
	link p;
	p=(link)malloc(sizeof(stack));
    p->data=c;
	p->next=head;
	head=p;
	return head;
}

link pop(link head,float *c)
{
	link top=head;
	if(head)
	{
		head=head->next;
		*c=top->data;
		free(top);
		return head;
	}
}
int isOperator(char e)
{
	switch(e)
	{
	case '+':
	case '-':
	case 'x':
	case '/':
		return 1;
	default:
		return 0;
	}
}
int priority(char e)
{
   switch(e)
   {
   case '(':
	   return 0;
   case '+':
   case '-':
	   return 1;
   case 'x':
   case '/':
	   return 2;
   }
}
int isDigit(char c)
{
	if(c<='9'&&c>='0')
		return 1;
	else
		return 0;

}
void main()
{

	char op;//�����ASCII��
	float e,a,b,result;
	char data[50];
	int i;
	Link s=(Link)malloc(sizeof(SqStack));
	operators=(Link)malloc(sizeof(SqStack));

	initStack(s);
	initStack(operators);
	while(1)
	{
            i=0;
			printf("please input the inorder expression:\n");
			scanf("%s",data);
			getchar();
			printf("s=%s\n",data);
			while(data[i]!='\0')
			{
				printf("data[%d]=%c\n",i,data[i]);
				if(!isDigit(data[i]))//��������
				{
						if(!isEmpty(s))//ջ����
						{
							Push(s,'\0');
							e=atof(s->base);//��ջ�������ĸ����ַ�ת��Ϊ������
							printf("e=%f\n",e);
							operand=push(operand,e);
							s->top=s->base;
						}
						if(isOperator(data[i]))//�������
						{
							if(!isEmpty(operators))
							{
								operators->top--;
								if(priority(data[i])<=priority(*(operators->top)))
								{//��ǰ�����С��ջ�������
									printf("top=%c,left=%d,right=%d\n",*(operators->top),priority(data[i]),priority(*(operators->top)));
                                    operators->top++;
									Pop(operators,&op);//ȡ��ջ�������
									printf("op=%c\n",op);
									operand=pop(operand,&a);//ȡ��ջ������������
									operand=pop(operand,&b);
									result=two_result(b,a,op);//�������㣬��������½�ջ
									operand=push(operand,result);
									printf("result1=%f\n",result);

								}
								else
								{//��ǰ���������ջ���������ֱ�ӽ�ջ
									operators->top++;
									Push(operators,data[i]);
									printf("not empty,data=%c\n",data[i]);
									i++;
								}
							}
							else//�����ջΪ�գ�ֱ�ӽ�ջ
							{
							Push(operators,data[i]);
							printf("empty,data=%c,i=%d\n",data[i],i);
							i++;
							}
						}
						else//�ȷ������ַ������
						{
							getchar();
							if(data[i]=='(')
							{
							Push(operators,data[i]);

							printf("(  push\n");
							}
							if(data[i]==')')
							{
								Pop(operators,&op);//ȡ��ջ�������
								printf("e=%c\n",op);
								while(op!='(')
								{
									operand=pop(operand,&a);//ȡ��ջ������������
									printf("a=%f",a);
									operand=pop(operand,&b);
									printf("  b=%f\n",b);
									result=two_result(b,a,op);//�������㣬��������½�ջ
								printf("result2=%f\n",result);

									operand=push(operand,result);									
								  Pop(operators,&op);//ȡ��ջ�������
								printf("e=%c\n",op);

								} 
							}
					        i++;			
						}
				}
				else//������
				{
					Push(s,data[i]);//�����ַ���ջ
					printf("%c,push,top-base=%d,i=%d\n",data[i],s->top-s->base,i);
				    i++;
				}

			}
			if(!isEmpty(s))
			{
				Push(s,'\0');
				e=atof(s->base);
				printf("e=%f\n",e);
				operand=push(operand,e);
				s->top=s->base;
			}
			while(!isEmpty(operators))
			{
				Pop(operators,&op);
				operand=pop(operand,&a);
				operand=pop(operand,&b);
				operand=push(operand,two_result(b,a,op));
			}
			operand=pop(operand,&a);
			printf("%s=%.2f\n",data,a);
	}
}

