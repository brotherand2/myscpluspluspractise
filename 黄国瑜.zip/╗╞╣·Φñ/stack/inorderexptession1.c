# include<stdio.h>

typedef struct node
{
	int data;
    struct node *next;
}Stack,*Link;
Link operand=NULL;//������
Link operators=NULL;//�����
int two_result(int a,int b,char e)
{
	switch(e)
	{
	case '+':return a+b;
	case '-':return a-b;
	case 'x':return a*b;
	case '/':return a/b;
	}
}
int isEmpty(Link s)
{
	return s==NULL;
}
Link push(Link head,int c)
{
	Link p;
	p=(Link)malloc(sizeof(Stack));
    p->data=c;
	p->next=head;
	head=p;
	return head;
}
Link pop(Link head,int *c)
{
	Link top=head;
	if(head)
	{
		head=head->next;
		*c=top->data;
		free(top);
		return head;
	}
}
int isOperator(char e)
{
	switch(e)
	{
	case '+':
	case '-':
	case 'x':
	case '/':
		return 1;
	default:
		return 0;
	}
}
int priority(char e)
{
   switch(e)
   {
   case '+':
   case '-':
	   return 1;
   case 'x':
   case '/':
	   return 2;
   }
}
int isDigigt(char c)
{
	if(c<='9'&&c>='0')
		return 1;
	else
		return 0;

}
void main()
{
	int e;
	int a,b,result;
	Link head=NULL;
	char data[50];
	int i;
	while(1)
	{
            i=0;
			printf("please input the inorder expression:\n");
			scanf("%s",data);
			while(data[i]!='\0')
			{
				if(isOperator(data[i]))
				{
					if(!isEmpty(operators))
					{
						if(priority(data[i])<=priority(operators->data))
						{
							operators=pop(operators,&e);
							operand=pop(operand,&a);
							operand=pop(operand,&b);
							result=two_result(b,a,e);
							operand=push(operand,result);
							printf("result=%d\n",result);

						}
						else
						{
							operators=push(operators,data[i]);
							i++;

						}
					}
					else
					{
					operators=push(operators,data[i]);
					i++;
					}
				}
				else
				{
					operand=push(operand,data[i]-48);
				    i++;
				}
			}
			while(!isEmpty(operators))
			{
				operators=pop(operators,&e);
				operand=pop(operand,&a);
				operand=pop(operand,&b);
				operand=push(operand,two_result(b,a,e));
			}
			operand=pop(operand,&a);
			printf("%s=%d\n",data,a);
	}



}

