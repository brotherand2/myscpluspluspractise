# include<stdio.h>
typedef struct node
{
	int data;
	struct node*next;
}Stack,*Link;
void push(Link *head,int c)
{
	Link p;
	p=(Link)malloc(sizeof(Stack));
	p->data=c;
	p->next=NULL;
	p->next=*head;
	*head=p;
}
int isEmpty(Link head)
{
	return head==NULL;
}
void pop(Link *head,int *c)
{
    if(!isEmpty(*head))
	{
		*c=(*head)->data;
		*head=(*head)->next;

	}
}
int isOperators(int t)
{
	switch(t)
	{
	  case '+':
	  case '-':
	  case 'x':
	  case '/':
		  return 1;
	  default:
		  return 0;

	}
}
int length(Link p)
{
	int count=0;
	while(p)
	{
		count++;
		p=p->next;
	}
	return count;
}
int two_result(int b,int a,int op)
{
	switch(op)
	{
	case '+':
		return a+b;
	case '-':
		return a-b;
	case 'x':
		return a*b;
	case '/':
		return a/b;

	}
}
int isDigit(char c)
{
	if(c>='0'&&c<='9')
		return 1;
	else
		return 0;
}

int priority(char c)
{
	switch(c)
	{
	case'(':
			 return 0;
	case'+':
	case'-':
		return 1;
	case 'x':
	case'/':
		return 2;
	}
}
void main()
{
	char in[50];
	char data[50];
	int i=0,j=0,operand1,operand2,operators,c;
    Link s=NULL,p=NULL;

	Link t=NULL;
    printf("please input the inorder expression:");
	gets(in);
    while(in[i]!='\0')
	{
       if(!isDigit(in[i]))
	   {
          if(isOperators(in[i]))
		  {
			  if(isEmpty(t))
				  push(&t,in[i]);
			  else
			  {
				  while(!isEmpty(t)&&priority(in[i])<=priority(t->data))
				  {
                     pop(&t,&c);
					 data[j]=c;
					 j++;
				  }
				  push(&t,in[i]);
			  }
		  }
		  else
		  {
			  if(in[i]=='(')
				  push(&t,in[i]);
			  if(in[i]==')')
			  {
				  pop(&t,&c);
				  while(c!='(')
				  {
					  data[j]=c;
					  pop(&t,&c);
					  j++;
				  }
			  }
		  }
	   }
	   else
	   {
          data[j]=in[i];
		 j++;
	   }
	   i++;
	}
	while(!isEmpty(t))
	{
		pop(&t,&c);
		data[j]=c;
		j++;
	}
	data[j]='\0';

	printf(" the preorder expression:");
	printf("%s\n",data);
    i=0;
	while(data[i]!='\0')
	{
		if(isOperators(data[i]))
		{
			pop(&p,&operand1);
			pop(&p,&operand2);
			push(&p,two_result(operand1,operand2,data[i]));
		}
		else
			push(&p,data[i]-48);
		i++;

	}
	pop(&p,&c);
	printf("%s=%d\n",data,c);
	
}