# include<stdio.h>
typedef struct node
{
	int data;
	struct node*next;
}Stack,*Link;
void push(Link *head,int c)
{
	Link p;
	p=(Link)malloc(sizeof(Stack));
	p->data=c;
	p->next=NULL;
	p->next=*head;
	*head=p;
}
int isEmpty(Link head)
{
	return head==NULL;
}
void pop(Link *head,int *c)
{
    if(!isEmpty(*head))
	{
		*c=(*head)->data;
		*head=(*head)->next;

	}
}
int isOperators(int t)
{
	switch(t)
	{
	  case '+':
	  case '-':
	  case 'x':
	  case '/':
		  return 1;
	  default:
		  return 0;

	}
}
int length(Link p)
{
	int count=0;
	while(p)
	{
		count++;
		p=p->next;
	}
	return count;
}
int two_result(int a,int b,int op)
{
	switch(op)
	{
	case '+':
		return a+b;
	case '-':
		return a-b;
	case 'x':
		return a*b;
	case '/':
		return a/b;

	}
}
int priority(char e)
{
   switch(e)
   {
   case '(':
   case ')':
	   return 0;
   case '+':
   case '-':
	   return 1;
   case 'x':
   case '/':
	   return 2;
   }
}
int isDigit(char c)
{
	if(c<='9'&&c>='0'||c=='.')
		return 1;
	else
		return 0;

}
void main()
{
    Link s=NULL,p=NULL,q=NULL;
	char data[50];
	int i=0,operand1,operand2,operators,t,e;
	printf("please input the inorder expression:\n");
	gets(data);
	while(data[i]!='\0')
	{
		push(&q,data[i]);
		i++;
	}
	while(!isEmpty(q))
	{
       pop(&q,&t);
	   if(!isDigit(t))
	   {
		   if(isOperators(t))
		   {
			   if(isEmpty(p))
				   push(&s,t);
			   else
			   {
				   while(!isEmpty(s)&&priority(t)<=priority(s->data))
				   {
					   pop(&s,&e);
					   push(&p,e);
				   }
				   push(&s,t);
			   }
		   }
		   else
		   {
			   if(t==')')
				   push(&s,t);
			   if(t=='(')
			   {
				   pop(&s,&e);
				   while(e!=')')
				   {
					   push(&p,e);
					   pop(&s,&e);
				   }
			   }
		   }
	   }
	   else
		   push(&p,t);
	}
	while(!isEmpty(s))
	{
		pop(&s,&e);
		push(&p,e);
	}
	printf("the preorder expression:");
	while(!isEmpty(p))
	{
		pop(&p,&e);
		push(&s,e);
		printf("%c",e);
	}
	printf("\n");
	while(!isEmpty(s))
	{
		pop(&s,&t);
		if(isOperators(t))
		{
			pop(&p,&operand1);
			pop(&p,&operand2);
			push(&p,two_result(operand1,operand2,t));
		}
		else
			push(&p,t-48);
	}
	pop(&p,&t);
	printf("%s=%d\n",data,t);
	
}