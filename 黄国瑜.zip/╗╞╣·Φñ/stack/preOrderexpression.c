# include<stdio.h>
typedef struct node
{
	int data;
	struct node*next;
}Stack,*Link;
void push(Link *head,int c)
{
	Link p;
	p=(Link)malloc(sizeof(Stack));
	p->data=c;
	p->next=NULL;
	p->next=*head;
	*head=p;
}
int isEmpty(Link head)
{
	return head==NULL;
}
void pop(Link *head,int *c)
{
    if(!isEmpty(*head))
	{
		*c=(*head)->data;
		*head=(*head)->next;

	}
}
int isOperators(int t)
{
	switch(t)
	{
	  case '+':
	  case '-':
	  case 'x':
	  case '/':
		  return 1;
	  default:
		  return 0;

	}
}
int length(Link p)
{
	int count=0;
	while(p)
	{
		count++;
		p=p->next;
	}
	return count;
}
int two_result(int a,int b,int op)
{
	switch(op)
	{
	case '+':
		return a+b;
	case '-':
		return a-b;
	case 'x':
		return a*b;
	case '/':
		return a/b;

	}
}
void main()
{
    Link s=NULL,p=NULL;
	char data[50];
	int i=0,operand1,operand2,operators,t;
	printf("please input the preorder expression:\n");
	gets(data);
	printf("data=%s\n",data);
	while(data[i]!='\0')
	{
		printf("data[%d]=%c",i,data[i]);
		push(&s,data[i]);
		i++;
	}
	printf("count=%d\n",length(s));
	while(!isEmpty(s))
	{
		pop(&s,&t);
		printf("s=%c\n",t);
		if(isOperators(t))
		{
			pop(&p,&operand1);
			pop(&p,&operand2);
			printf("a=%c,b=%c\n",operand1,operand2);

			push(&p,two_result(operand1,operand2,t));
		}
		else
			push(&p,t-48);
	}
	pop(&p,&t);
	printf("%s=%d\n",data,t);
	
}