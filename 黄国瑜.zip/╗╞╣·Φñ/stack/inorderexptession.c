# include<stdio.h>
# include<stdlib.h>
typedef struct node
{
	int data;
    struct node *next;
}Stack,*Link;
typedef struct Node
{
	float data;
    struct Node *next;
}stack,*link;

link operand=NULL;//������
Link operators=NULL;//�����
typedef struct 
{
	char *top;
	char *base;
	int stackSize;

}SqStack;
void initStack(SqStack *s)
{
	s->top=s->base=(char*)malloc(sizeof(char)*10);
	s->stackSize=10;
}
void Push(SqStack *s,char e)
{
   if(s->top-s->base==10)
   {
	   s->base=(char*)realloc(s->base,(s->stackSize+10)*sizeof(char));
	   s->top=s->base+10;
	   s->stackSize+=10;
   }
   *(s->top)=e;
   s->top++;

}
void Pop(SqStack *s,char *e)
{
	if(s->top==s->base)
		printf("the stack is null");
	else
	{
		s->top--;
		*e=*(s->top);
	}
}

float two_result(float a,float b,char e)
{
	switch(e)
	{
	case '+':return a+b;
	case '-':return a-b;
	case 'x':return a*b;
	case '/':return a/b;
	}
}
int isEmpty(Link s)
{
	return s==NULL;
}
Link push(Link head,int c)
{
	Link p;
	p=(Link)malloc(sizeof(Stack));
    p->data=c;
	p->next=head;
	head=p;
	return head;
}
link push1(link head,float c)
{
	link p;
	p=(link)malloc(sizeof(stack));
    p->data=c;
	p->next=head;
	head=p;
	return head;
}
Link pop(Link head,int *c)
{
	Link top=head;
	if(head)
	{
		head=head->next;
		*c=top->data;
		free(top);
		return head;
	}
}
link pop1(link head,float *c)
{
	link top=head;
	if(head)
	{
		head=head->next;
		*c=top->data;
		free(top);
		return head;
	}
}
int isOperator(char e)
{
	switch(e)
	{
	case '+':
	case '-':
	case 'x':
	case '/':
		return 1;
	default:
		return 0;
	}
}
int priority(char e)
{
   switch(e)
   {
   case '(':
	   return 0;
   case '+':
   case '-':
	   return 1;
   case 'x':
   case '/':
	   return 2;
   }
}
int isDigit(char c)
{
	if(c<='9'&&c>='0')
		return 1;
	else
		return 0;

}
void main()
{

	int op;//�����ASCII��
	float e,a,b,result;
	Link head=NULL;
	SqStack s;
	char data[50];
	int i;
	initStack(&s);
	while(1)
	{
            i=0;
			printf("please input the inorder expression:\n");
			scanf("%s",data);
			while(data[i]!='\0')
			{
				if(!isDigit(data[i]))//��������
				{
						if((s.top-s.base)!=0)//ջ����
						{
							Push(&s,'\0');
							e=atof(s.base);//��ջ�������ĸ����ַ�ת��Ϊ������
							printf("e=%f\n",e);
							operand=push1(operand,e);
							s.top=s.base;
						}
						if(isOperator(data[i]))//�������
						{
							if(!isEmpty(operators))
							{
								operators=pop(operators,&op);//ȡ��ջ�������
                                printf("op=%c\n",op);
								if(priority(data[i])<=priority(op))
								{//��ǰ�����С��ջ�������
									operand=pop1(operand,&a);//ȡ��ջ������������
									operand=pop1(operand,&b);
									printf("a=%f,b=%f\n",a,b);

									result=two_result(b,a,op);//�������㣬��������½�ջ
									operand=push1(operand,result);
									printf("result=%f\n",result);

								}
								else
								{//��ǰ���������ջ���������ֱ�ӽ�ջ
							     	operators=push(operators,op);//�Ż�ջ�������
									operators=push(operators,data[i]);
									printf("not empty,data=%c\n",data[i]);
									i++;
								}
							}
							else//�����ջΪ�գ�ֱ�ӽ�ջ
							{
							operators=push(operators,data[i]);
							printf("empty,data=%c\n",data[i]);
							i++;
							}
						}
						else//�ȷ������ַ������
						{
							if(data[i]=='(')
							operators=push(operators,data[i]);
							if(data[i]==')')
							{
								operators=pop(operators,&op);//ȡ��ջ�������
								printf("e=%c\n",op);
								while(op!='(')
								{
									operand=pop1(operand,&a);//ȡ��ջ������������
									operand=pop1(operand,&b);
									result=two_result(b,a,op);//�������㣬��������½�ջ
								   printf("result=%f\n",result);

									operand=push1(operand,result);									
								    operators=pop(operators,&op);//ȡ��ջ�������
								printf("e=%c\n",op);

								} 
							}
					        i++;			
						}
				}
				else//������
				{
					Push(&s,data[i]);//�����ַ���ջ
					printf("%c,push,top-base=%d\n",data[i],s.top-s.base);
				    i++;
				}

			}
			if((s.top-s.base)!=0)
			{
				Push(&s,'\0');
				e=atof(s.base);
				printf("e=%f\n",e);
				operand=push1(operand,e);
				s.top=s.base;
			}
			while(!isEmpty(operators))
			{
				operators=pop(operators,&op);
				operand=pop1(operand,&a);
				operand=pop1(operand,&b);
				operand=push1(operand,two_result(b,a,op));
			}
			operand=pop1(operand,&a);
			printf("%s=%.2f\n",data,a);
	}
}

