# include<stdio.h>

void main()
{
	char c,t;
    
	while((c=getchar())!='q')
	{
	//	while((t=getchar())!='\n')
		//	;
          if(c!='a'&&c!='d')
		  {
			  printf("continue\n");
			  continue;
		  }
		  printf("%c ",c);
	}
}