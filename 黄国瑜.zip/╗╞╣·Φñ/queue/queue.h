# include<stdio.h>
//# include<stdbool.h>
# define MAXQUEUE 10
typedef struct node
{
	int item;
	struct node *next;
}Node;
typedef struct queue
{
	Node *front;
	Node *rear;
	int count;
}Queue;
typedef Queue *List;
void Iniqueue(List p);
int ListIsEmpty(List p);
int ListIsFull(List p);
int ListCount(List p);
int DeQueue(List p);
int EnQueue(List p);
void TraverseQueue(List p,void (*show)(Node * p));
void EmptyList(List p);
void  show(Node * p);
