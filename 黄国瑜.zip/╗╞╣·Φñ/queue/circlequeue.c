# include<stdio.h>
# define max 10
int front=0,rear=0;
void menu()
{
	printf("=============================================\n");
	printf("=====1�������У�2��������====================\n");
	printf("=============================================\n");
}
int isEmpty()
{
	return front==rear;
}
int isFull()
{
	return (rear+1)%max==front;


}
void enQueue(int q[])
{
	int num;
	if(isFull())
		printf("the queue is full\n");
	else
	{
		printf("please input the integer you want to input:");
		scanf("%d",&num);
		q[rear]=num;
		rear=(rear+1)%max;

	}
}
void deQueue(int q[])
{
   if(isEmpty())
	   printf("the queue is empty\n");
   else
   {
	   printf("%d has delete\n",q[front]);
	   front=(front+1)%max;

   }
}
void traverseQueue(int q[])
{
	int i;
	for(i=front;i!=rear;i=(i+1)%max)
		printf("%d ",q[i]);
	printf("\n");
}
void main()
{
	int queue[max];
	int i;
	while(1)
	{
		menu();
		printf("please input you choice:");
		scanf("%d",&i);
		switch(i)
		{
		case 1:
			enQueue(queue);
			traverseQueue(queue);
			break;
		case 2:
			deQueue(queue);
			traverseQueue(queue);
			break;
		default:
			printf("input error!\n");
		}
	}

}