# include<stdio.h>
# include<stdlib.h>
typedef struct
{
	char *base;
	char *top;
	int stacksize;
}Stack;
void initStack(Stack *s)
{
	s->top=s->base=(char *)malloc(sizeof(char)*10);
	s->stacksize=10;
}
int stackLength(Stack *s)
{
	return s->top-s->base;
}
void push(Stack *s,char c)
{
	if(s->top-s->base==s->stacksize)
	{
		s->base=(char *)realloc(s->base,sizeof(char)*(10+s->stacksize));
		s->top=s->base+s->stacksize;
		s->stacksize+=10;
	}
	*(s->top)=c;
	s->top++;
}
void pop(Stack *s,char *c)
{
	if(!stackLength(s))
		return;
	s->top--;
	*c=*(s->top);
}

void main()
{
	Stack s1;
	char e;
	initStack(&s1);
	printf("please input the first integer(press '#'to quit):\n");
	scanf("%c",&e);
	while(e!='#')
	{
		if(e>='0'&&e<='9')
		push(&s1,e);
		scanf("%c",&e);
	}
	printf("the result is:\n");
	while(stackLength(&s1))
	{
		pop(&s1,&e);
		printf("%d",e);
	}



}






