//�ַ�������
# include<stdio.h>
# include"string.c"
void main()
{
   int flag=1;//ѭ����־
   int choice;
   char s1[100],s2[100];
   int len;//��¼�ַ�������
   int position;//λ��
   char **s;//�ַ�ָ���ָ��
   char *str;//�ַ���ָ��
   int i;
   char c;//���ڽ������õĻ��з�
   while(flag)
   {
      menu();
	  printf("please input your choice:");
	  scanf("%d",&choice);
	  while((c=getchar())!='\n')
			  ;//���ջ��з�
	  switch(choice)
	  {
	  case 0:flag=0;break;
	  case 1:
		  printf("input the the string you want to count :");
		  gets(s1);
		  len=strLen(s1);
		  printf("%s 's length is %d\n",s1,len);
		  break;
	  case 2:
		  printf("input the string you want to copy :");
		  gets(s1);
          strCpy(s2,s1);
		  printf("the copy string is s2 is %s\n",s2);
		  break;
	  case 3:
		  printf("input the fistst string:");
		  gets(s1);
		  printf("input the second string to merge:");
		  gets(s2);
		  strCat(s1,s2);
		  printf("the merge string is %s\n",s1);
		  break;
	  case 4:
		  printf("input  the string you want to replace :");
		  gets(s1);
		  printf("input the position begin to replace:");
		  scanf("%d",&position);
		  while((c=getchar())!='\n')
			  ;
          printf("what string do you want to replace after %d's? ",position);
		  gets(s2);
		  strRep(s1,s2,position);
		  printf("the new string is: %s\n",s1);
		  break;
	  case 5:
		  printf("input  the string you want to insert :");
		  gets(s1);
		  printf("input the position begin to insert:");
		  scanf("%d",&position);
	      while((c=getchar())!='\n')
			  ;//���ջ��з�
		  printf("what string do you want to insert after %d's? ",position);
		  gets(s2);
		  strIns(s1,s2,position);
		  printf("the new string is :%s\n",s1);
		  break;
	  case 6:
		  printf("input  the string you want to delete:");
		  gets(s1);
		  printf("input the position begin to delete:");
		  scanf("%d",&position);
		  printf("input the length you want to delete:");
		  scanf("%d",&len);
		  strDel(s1,position,len);
		  printf("the new string is: %s\n",s1);
		  break;
	  case 7:
		  printf("input the fistst string:");
		  gets(s1);
		  printf("input the second string :");
		  gets(s2);
		  if(strCmp(s1,s2)==0)
		  printf(" %s == %s\n",s1,s2);
		  else
			  if(strCmp(s1,s2)>0)
		        printf(" %s > %s\n",s1,s2);
			  else
		        printf(" %s < %s\n",s1,s2);
		  break;
	  case 8:
		  printf("input  the string you want to cut:");
		  gets(s1);
		  printf("input the position begin to cut:");
		  scanf("%d",&position);
		  printf("input the length you want to cut:");
		  scanf("%d",&len);
		  str=subStr(s1,position,len);
		  printf("the cut string is: %s\n",str);
		  break;
	  case 9:
		  printf("input the origin string :");
		  gets(s1);
		  printf("input the string you will search:");
		  gets(s2);
          position=strIndexof(s1,s2);
		  if(position!=-1)
			  printf("%s is in the %dth position\n",s2,position);
		  else
			  printf("not found\n");
		  break;
	  case 10:
		  printf("input the string you want to cut apart:");
		  gets(s1);
		  s=partition(s1,&len);
          for(i=0;i<len;i++)
		  {
			  printf("%d   %s\n",i+1,s[i]);
		  }
          break;
      default:printf("input error\n");break;
	  }
   }
}