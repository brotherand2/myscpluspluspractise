# include<stdio.h>
# include"string.c"
void main()
{
	char s1[20],s2[20],**s3;
	int locate=0,i,choice;
	printf("input i:");
	scanf("%d  ",&i);
	printf("i=%d",i);
	/*while(1)
	{
		printf("input choice:");
		scanf("%d",&choice);
		while((getchar())!='\n')
			;

		switch(choice)
		{
		case 1:
		printf("input s1:");
		gets(s1);
		printf("input integer:");
		scanf("%d",&i);
		printf("input anothor inger:");
		scanf("%d",&locate);
		while((getchar())!='\n')
			;
		printf("input  s2:");
		gets(s2);
		printf("s1=%s,s2=%s,i=%d,locate=%d\n",s1,s2,i,locate);
		break;
		}
	}


    //strIns(s1,s2,5);
   // strDel(s2,9,4);
	//printf("s2=%s\n",s2);
	if(strCmp(s1,s2)==0)
		printf("%s ==%s",s1,s2);
	else
	if(strCmp(s1,s2)==-1)
		printf("%s <%s",s1,s2);
	else
		printf("%s >%s",s1,s2);
		
    //s3=subStr(s1,4,5);
	//printf("s3=%s\n",s3);
    locate=strIndexof(s1,s2);f
	if(locate!=-1)
		printf("the locate:%d\n",locate);
	else
		printf("no exit\n");
   s3=partition(s1,&locate);
   printf("locate=%d\n",locate);
   for(i=0;i<locate;i++)

		
		printf("%d   %s\n",i+1,s3[i]);*/
	getchar();
}
