# include<stdio.h>
/*
    ��δʵ�ִ���������������ϣ��ʵ�ִ󸡵�����Ӽ��˳���ʵ�ֺ����õ�����ʽ
*/
typedef struct
{
	char *base;
	char *top;
	int stacksize;
}Stack;
void initStack(Stack *s)
{
	s->top=s->base=(char *)malloc(sizeof(char)*10);
	s->stacksize=10;
}
int stackLength(Stack s)
{
	return s.top-s.base;
}
void push(Stack *s,char c)
{
	if(s->top-s->base==s->stacksize)
	{
		s->base=(char *)realloc(s->base,sizeof(char)*(10+s->stacksize));
		s->top=s->base+s->stacksize;
		s->stacksize+=10;
	}
	*(s->top)=c;
	s->top++;
}
void pop(Stack *s,char *c)
{
	if(!stackLength(*s))
		return;
	s->top--;
	*c=*(s->top);
}
void ADD(Stack *s1,Stack *s2,Stack *s3)
{
	int c=0;
	char a,b,e;
	while(stackLength(*s1)&&stackLength(*s2))
	{
        pop(s2,&b);
		pop(s1,&a);
		e=(a-48)+(b-48)+c-48;
		if(e>='9')
		{
			e=e-'9'-1+48;
			c=1;
		}
		else
			c=0;
		push(s3,e);
	}
	while(stackLength(*s1))
	{
		pop(s1,&a);
		e=a+c;
		if(e>='9')
		{
			e=e-'9'-1+48;
			c=1;
		}
		else
			c=0;
		push(s3,e);
	}
	while(stackLength(*s2))
	{
		pop(s2,&b);
		e=b+c;
		if(e>='9')
		{
			e=e-'9'-1+48;
			c=1;
		}
		else
			c=0;
		push(s3,e);
	}
	if(c==1)
		push(s3,'1');
}

void main()
{
	Stack s1,s2,s3;
	char e;
	initStack(&s1);
	initStack(&s2);
	initStack(&s3);
	printf("please input the first integer(press '#'to quit):\n");
	scanf("%c",&e);
	while(e!='#')
	{
		if(e>='0'&&e<='9')
		push(&s1,e);
		scanf("%c",&e);
	}
	getchar();
	printf("please input the second integer(press '#'to quit):\n");
	scanf("%c",&e);
	while(e!='#')
	{
		if(e>='0'&&e<='9')
		push(&s2,&e);
		scanf("%c",&e);
	}
	//ADD(&s1,&s2,&s3);
	printf("the result is:\n");
	while(stackLength(s1))
	{
		pop(&s1,&e);
		printf("%d",e);
	}
	printf("\n");

}






