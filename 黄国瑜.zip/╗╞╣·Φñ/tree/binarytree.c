# include<stdio.h>
typedef struct tree
{
	int data;
	int left;
	int right;
}Tree;
typedef struct node
{
	int data;
	struct node *left;
	struct node *right;
}Node,*BTree;
Tree btree[20];
BTree insertNode(BTree root,int e)
{
    BTree p;
	if(root==NULL)
	{
		p=(BTree)malloc(sizeof(Node));
		p->data=e;
		p->left=NULL;
		p->right=NULL;
		root=p;
	}
	else
	{
		if(e>=root->data)
			root->right=insertNode(root->right,e);
		else
			root->left=insertNode(root->left,e);
	}
	return root;
}
BTree createBinary2(int a[],int n)
{
    int i;
	BTree root=NULL;
	for(i=1;i<=n;i++)
      root=insertNode(root,a[i]);
	return root;
}
void preordertraverseTree(BTree root)
{
    if(root)
	{
		printf("%d ",root->data);
		preordertraverseTree(root->left);
		preordertraverseTree(root->right);
	}
}
void inordertraverseTree(BTree root)
{
    if(root)
	{
		inordertraverseTree(root->left);
		printf("%d ",root->data);
		inordertraverseTree(root->right);
	}
}
void postordertraverseTree(BTree root)
{
    if(root)
	{
		postordertraverseTree(root->left);
		postordertraverseTree(root->right);
		printf("%d ",root->data);
	}
}
void createBinary1(int a[],int n)
{
	int i,level,find;
	btree[1].data=a[1];
	for(i=2;i<=n;i++)
	{
		level=1;
		find=0;
		while(find==0)
		{
			if(a[i]>=btree[level].data)
			{
				if(btree[level].right!=-1)
					level=level*2+1;
				else
				    find=1;
			}
			else
			{
				if(btree[level].left!=-1)
					level*=2;
				else
					find=-1;
			}
		}
		if(find==1)
		{
			btree[level].right=level*2+1;
			btree[level*2+1].data=a[i];
		}
		else
		{
			btree[level].left=level*2;
			btree[level*2].data=a[i];
		}
	}
}
void createBinary(int tree[],int a[],int n)
{
	int i,level;
	tree[1]=a[1];
	for(i=2;i<=n;i++)
	{
		level=1;
		while(level<20&&tree[level])
		{
			if(a[i]>=tree[level])
			   level=level*2+1;
			else
				level*=2;

		}
		tree[level]=a[i];
	}
}
void main()
{
	int i=1,k,data;
	int a[20];//��������������
	int tree[20];//���ڽ�����������α���
	BTree btree2=NULL;
	printf("input integet(input 0 to quit):");
	scanf("%d",&data);
    while(data)
	{
    	a[i++]=data;
    	printf("input integet(input 0 to quit):");
		scanf("%d",&data);
	}
	printf("num=%d\n\n",i-1);
    for(k=1;k<20;k++)
	{
      tree[k]=0;
	  btree[k].data=0;
	  btree[k].left=-1;
	  btree[k].right=-1;
	}
	createBinary(tree,a,i-1);
	printf("tree1:\n");
	for( k=1;k<20;k++)
		printf("%d  ",tree[k]);
	printf("\ntree2:\n"); 

    createBinary1(a,i-1);
	for(k=1;k<20;k++)
	{
		if(btree[k].data!=0)
			printf("left=%d,data=%d,right=%d\n",btree[k].left,btree[k].data,btree[k].right);
	}
	btree2=createBinary2(a,i-1);
	printf("the preorder output is:\n");
	preordertraverseTree(btree2);
	printf("\nthe inorder output is:\n");
	inordertraverseTree(btree2);
	printf("\nthe postorder output is:\n");
	postordertraverseTree(btree2);
	while(1)
	{
       
	}
	printf("\n");
}