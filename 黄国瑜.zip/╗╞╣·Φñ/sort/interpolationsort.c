//�岹����

# include<stdio.h>

#define Max	20
int	data[Max] = {  12,  16,  19,  22,  25,
				  32,  39,  48,  55,  57,
				  58,  63,  68,  69,  70,
				  78,  84,  88,  90,  97};	/* �������� */
int Counter = 1;	                           /* ������ */
int interpolation(int num)
{
    int left=0,right=Max-1;
	int middle;
	middle=left+(num-data[left])*(right-left)/(data[right]-data[left]);
	if(middle>right)
		middle=right;
	if(middle<left)
		middle=left;
	while(left<right)
	{
		if(data[middle]==num)
		{
			printf("data[%d]=%d\n",middle,num);
			return 1;
		}
		else
			if(data[middle]>num)
				right=middle-1;
			else
				left=middle+1;
		middle=left+(num-data[left])*(right-left)/(data[right]-data[left]);
		if(middle>right)
			middle=right;
		if(middle<left)
			middle=left;
		Counter++;
		
	}
	return 0;
}
void main()
{
     int num;
	 printf("please input the integer you want to search:");
	 scanf("%d",&num);
	 if(interpolation(num))
		 printf("search time:%d\n",Counter);
	 else
		 printf("not found\n");
}