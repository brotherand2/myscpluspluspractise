/*
=========================================
���ϲ��ҷ�    ����ʱֻ����һ���֣�
  ===========================================
*/
# include<stdio.h>
# define max 20
int data[max]={  12,  16,  19,  22,  25, 32,  39,  48,  55,  57, 58,  63,  68,  69,  70, 78,  84,  88,  90, 97};
int count=0;
int fib(int n)
{
    if(n==1||n==0)
		return 1;
	else 
		return fib(n-1)+fib(n-2);
}


int fibonaccisort(int n,int key)
{
	int temp,distance1,distance2,root;
	root=fib(n);
	distance1=fib(n-1);
	distance2=fib(n-2);
	printf("n=%d\n",n);
	do
	{
		if(data[root-1]==key)
		{
			printf("data[%d]=%d\n",root-1,data[root-1]);
			return 1;
		}
		else
			if(data[root-1]>key)
			{
				root=root-distance2;
				temp=distance1;
				distance1=distance2;
                distance2=temp-distance1;
			}
			else
			{
                root=root+distance2;
				distance1=distance1-distance2;
				distance2=distance2-distance1;
			}
			printf("n=%d,%d----%d\n",root,data[root-1],key);
			count++;
	}while(distance2>=0);
	return 0;

}
void main()
{
    int fina=1,i;
	int keys;
	while(fib(fina)<max)
	  fina++;//max��Χ�ڷ��ϵĽ���
	printf("fina=%d\n",fina);
	for(i=0;i<max;i++)
		printf("data[%d]=%d\n",i,data[i]);
	printf("please input the value you want to search:");
	scanf("%d",&keys);
	if(fibonaccisort(fina-1,keys))
		printf("search time:%d\n",count);
	else
		printf("not found\n");
}