/*==============================
     һά����ĸ߼�Ӧ��
=================================
*/
# include<stdio.h>

void main()
{
	int n,i,j;
    int data[100],digit=1;
	for(i=0;i<100;i++)
		data[i]=0;
	data[1]=1;
	printf("input a number what you want to calculate:");
	scanf("%d",&n);
    for(i=1;i<=n;i++)
	{
         for(j=1;j<=digit;j++)
			 data[j]*=i;
		 for(j=1;j<=digit;j++)
		 {
			 if(data[j]>=10)
			 {
				 if(j==digit)
					 digit++;
				 data[j+1]+=data[j]/10;
				 data[j]=data[j]%10;
			 }
		 }
			printf("%d!=",i);

		for(j=digit;j>=1;j--)
			printf("%d",data[j]);
		printf("\n");
	}

}